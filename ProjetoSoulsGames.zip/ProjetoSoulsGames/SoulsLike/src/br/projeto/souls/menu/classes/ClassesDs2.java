package br.projeto.souls.menu.classes;

public class ClassesDs2 {

}
