package br.projeto.souls.core;

public class StatusBase {
    public StatusBase() {

    }
}
