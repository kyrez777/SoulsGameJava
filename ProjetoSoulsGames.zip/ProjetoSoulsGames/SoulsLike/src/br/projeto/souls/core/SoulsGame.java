package br.projeto.souls.core;

public class SoulsGame {
    //Classe pai das classes jogos
}
