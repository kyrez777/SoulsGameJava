package br.projeto.souls.core;

public class Status {

}
